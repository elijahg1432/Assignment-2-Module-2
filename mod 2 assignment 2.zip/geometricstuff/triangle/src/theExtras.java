public class theExtras extends GeometricObject {
    public theExtras(String color, boolean filled) {
      super(color, filled);
    }

    public double getArea() {
      return 0;
    }

    public double getPerimeter() {
      return 0;
    }
  
}

