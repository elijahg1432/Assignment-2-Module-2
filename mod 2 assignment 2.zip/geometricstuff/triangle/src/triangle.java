//created by Elijah Gonzalez, started on August 29th, finished August 30th. the user inputs specifications of a triangle, the program outputs it.

import java.util.Scanner;

public class triangle {

    //we must set default data fields for the sides of our triangle,as well as "extra" info, which is what color we would like it to be, and if the triangle is colored in (filled) or not.
    private double side1 = 1.0;
    private double side2 = 1.0;
    private double side3 = 1.0;
    private GeometricObject extras;

    //this is a constructor that makes a triangle with our specified side lengths only. it is not needed, but the textbook says we need one that just has a triangle with 3 sides. so here it is.
    public triangle(double side1, double side2, double side3){
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }

    //this constructor does the same, but includes our extra features of filled and its color
    public triangle(double side1, double side2, double side3, GeometricObject extras) {
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
        this.extras = extras;
    }
    
    //BETWEEN HERE.
    public double getSide1() {
        return side1;
    }
    
    public double getSide2() {
        return side2;
    }

    public double getSide3() {
        return side3;
    }
    //AND HERE, are all accessor methods for each sides. 1 for each.

    //returns color from getColor() method from inside GeometricObject.java
    public String getColor() {
        return extras.getColor();
    }

    //another method, this time isFilled() from the same place, to return the true/false of the variable
    public boolean isFilled() {
        return extras.isFilled();
    }

    //method 
    public double getArea() {
        double s = (side1 +side2 +side3)/2;
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }

    public double getPerimeter() {
        return side1 + side2 + side3;
    }

    public String toString() {
        return "Triangles sides: " +side1 +", " +side2 + ", " +side3
        + " Area: " + getArea() + " Perimter: " +getPerimeter() + " Color: " + getColor()
        + " Filled: " + isFilled();
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Enter first side of triangle: ");
        double side1 = input.nextDouble();

        System.out.println("Enter second side: ");
        double side2 = input.nextDouble();

        System.out.println("Enter final side: ");
        double side3 = input.nextDouble();

        System.out.println("Enter color of triangle: ");
        String color = input.next();

        System.out.println("Is the triangle filled? (input true or false) ");
        boolean filled = input.nextBoolean();

        GeometricObject extras = new theExtras(color, filled);


        triangle usTriangle = new triangle(side1, side2, side3, extras);

        System.out.println(usTriangle.toString());

        input.close();
    }
   
}